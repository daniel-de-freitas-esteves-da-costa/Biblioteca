import './App.css'
import Header from './Components/Header/Headers'

import Livros from './../src/Components/Card/CardLivros'

function App()
{
  return(
    <div className='min-h-screen bg-gray-100 divCompleta'>
      <div className="divCompleta">
        <Header />

      

      </div>
      
    <div className="Livros">
        <Livros auto='Son Goku' titulo='Son Goku SSJ 1' categoria='Ação'/>
        <Livros auto='Vegeta' titulo='Vegeta SSJ 1' categoria='Ação'/>
        <Livros auto='Gogeta' titulo='Gogeta Sayiajin Blue' categoria='Ação'/>
    </div>


    </div>
  )
}

export default App;
