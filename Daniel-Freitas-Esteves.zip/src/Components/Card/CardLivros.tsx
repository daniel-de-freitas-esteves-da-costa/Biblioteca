import './CardLivro.css'

interface CardLivros
{
    titulo: string,
    auto: string,
    categoria: string
}


function CardLivros({ titulo, auto, categoria, }: CardLivros)
{
    return(
        <article className="flex gap-6 border-b border-gray-300 py-6">
            <div className="h-32 w-24 shrink-0 border-2 border-black">

            </div>

            <div>
                <h3 className="text-x1 font-bold text-gray-900"> {titulo} </h3>

                <p className="mt-2 text-gray-600"> {auto} </p>

                <p className="mt-2 text-sm text-gray-500"> { categoria } </p>
            </div>
        </article>
    )
}

export default CardLivros;