import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'




// fazer a paginação dos documentos
import { BrowserRouter, Routes, Route } from 'react-router-dom';

import Sobre from './Sobre.tsx'

import Teste from './Components/Header/Headers.tsx'


createRoot(document.getElementById('root')!).render(
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<App />} />
      <Route path="/Sobre" element={<Sobre />}/>
      <Route path="/teste" element={<Teste />}/>
    </Routes>
  </BrowserRouter>
)
